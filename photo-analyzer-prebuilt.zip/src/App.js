import React, { useState } from "react";
import exifr from "exifr";

function App() {
  const [result, setResult] = useState(null);

  async function handleImageUpload(e) {
    const file = e.target.files[0];
    if (!file) return;

    // Extract EXIF (GPS)
    const exif = await exifr.parse(file, true);
    const gps = exif?.latitude && exif?.longitude
      ? `📍 GPS: ${exif.latitude}, ${exif.longitude}`
      : "No GPS data found";

    // Fake keywords for now
    const keywords = {
      who: "Unknown (needs Vision API)",
      what: "Landscape, Nature",
      where: gps,
      description: "This is a placeholder description of the photo."
    };

    setResult(keywords);
  }

  return (
    <div style={{ padding: 20, fontFamily: "sans-serif" }}>
      <h1>📸 Photo Analyzer</h1>
      <input type="file" accept="image/*" onChange={handleImageUpload} />
      {result && (
        <div style={{ marginTop: 20 }}>
          <p><strong>Who:</strong> {result.who}</p>
          <p><strong>What:</strong> {result.what}</p>
          <p><strong>Where:</strong> {result.where}</p>
          <p><strong>Description:</strong> {result.description}</p>
        </div>
      )}
    </div>
  );
}

export default App;